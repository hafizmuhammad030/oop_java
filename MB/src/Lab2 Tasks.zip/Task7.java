public class Task7{
    static boolean saving_mode = false;
    public static void main(String[] args)
    {
        saving_mode = true;
        if(saving_mode)
        { System.out.println("Energy-saving mode: Enabled");
        }
        else
        {
            System.out.println("Energy-saving mode: Disabled");
        }
        saving_mode = false;
        if(saving_mode)
        { System.out.println("Energy-saving mode: Enabled");
        }
        else
        {
            System.out.println("Energy-saving mode: Disabled");
        }




    }


    }


