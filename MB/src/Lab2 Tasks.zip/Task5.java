public class Task5 {
    public static void main(String[] args)
    {
        boolean isLightON = true;

        if(isLightON)
        {
            System.out.println("Light is ON");
        }
        else
        {
            System.out.println("Light is OFF");
        }
    }

}
