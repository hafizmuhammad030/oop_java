public class TASK1 {
    public static void main(String[] args)
    {
        int BrightenessLevel = 0;
        boolean isLighton = false;

        if(isLighton)
        {
            System.out.println("Light Status: On");
        }
        else
        {
            System.out.println("Light Status: Off");

        }
        System.out.println("Brighteness level: 0%");
    }

}
