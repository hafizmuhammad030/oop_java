public class Task3 {
    public static void main(String [] args)
    {

        String mode = "Energy Saving Mode";
        String updatedMode = mode + " - Night Time";

        System.out.println("Current Mode: " + mode);
        System.out.println("Updated Mode: " + updatedMode);

        System.out.println("String immutability prevents direct modification..!!!");
    }
}
