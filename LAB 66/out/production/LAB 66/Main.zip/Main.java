import java.util.Scanner;

class Node {
    int data;
    Node next;
    Node prev;

    Node(int d) {
        data = d;
        next = null;
        prev = null;
    }
}

public class Main {
    static Node head = null;

    public static void insertAtFront(int value) {
        Node newNode = new Node(value);
        if (head == null) {
            newNode.next = newNode.prev = newNode;
            head = newNode;
        } else {
            Node tail = head.prev;
            newNode.next = head;
            newNode.prev = tail;
            tail.next = head.prev = newNode;
            head = newNode;
        }
    }

    public static void insertAtEnd(int value) {
        Node newNode = new Node(value);
        if (head == null) {
            newNode.next = newNode.prev = newNode;
            head = newNode;
        } else {
            Node tail = head.prev;
            newNode.next = head;
            newNode.prev = tail;
            tail.next = head.prev = newNode;
        }
    }

    public static Integer removeFromFront() {
        if (head == null) {
            System.out.println("List is empty.");
            return null;
        }

        int val = head.data;
        if (head.next == head) {
            head = null;
        } else {
            Node tail = head.prev;
            head = head.next;
            head.prev = tail;
            tail.next = head;
        }
        return val;
    }

    public static Integer removeFromEnd() {
        if (head == null) {
            System.out.println("List is empty.");
            return null;
        }

        Node tail = head.prev;
        int val = tail.data;

        if (head.next == head) {
            head = null;
        } else {
            Node newTail = tail.prev;
            newTail.next = head;
            head.prev = newTail;
        }
        return val;
    }

    public static boolean search(int value) {
        if (head == null) return false;

        Node temp = head;
        do {
            if (temp.data == value)
                return true;
            temp = temp.next;
        } while (temp != head);

        return false;
    }

    public static void display() {
        if (head == null) {
            System.out.println("List is empty.");
            return;
        }

        Node temp = head;
        System.out.print("List: ");
        do {
            System.out.print(temp.data + " ");
            temp = temp.next;
        } while (temp != head);
        System.out.println();
    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int choice = -1;

        while (choice != 0) {
            System.out.println("\nMenu:");
            System.out.println("1. Insert at front");
            System.out.println("2. Insert at end");
            System.out.println("3. Remove from front");
            System.out.println("4. Remove from end");
            System.out.println("5. Search");
            System.out.println("6. Display");
            System.out.println("0. Exit");
            System.out.print("Enter your choice: ");
            choice = sc.nextInt();

            if (choice == 1) {
                System.out.print("Enter value: ");
                int val = sc.nextInt();
                insertAtFront(val);
            } else if (choice == 2) {
                System.out.print("Enter value: ");
                int val = sc.nextInt();
                insertAtEnd(val);
            } else if (choice == 3) {
                Integer removed = removeFromFront();
                if (removed != null)
                    System.out.println("Removed: " + removed);
            } else if (choice == 4) {
                Integer removed = removeFromEnd();
                if (removed != null)
                    System.out.println("Removed: " + removed);
            } else if (choice == 5) {
                System.out.print("Enter value to search: ");
                int val = sc.nextInt();
                boolean found = search(val);
                if (found)
                    System.out.println("Value found.");
                else
                    System.out.println("Value not found.");
            } else if (choice == 6) {
                display();
            } else if (choice == 0) {
                System.out.println("Exiting program.");
            } else {
                System.out.println("Invalid choice.");
            }
        }

        sc.close();
    }
}
